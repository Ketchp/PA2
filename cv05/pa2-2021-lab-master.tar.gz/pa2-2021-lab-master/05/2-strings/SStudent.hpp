#pragma once

#include "string.hpp"

struct SStudent
{
	my_std::string m_name;
	int m_knowledge_level;
};
