#include "string.hpp"

char & my_std::string::operator[] ( size_t idx )
{
	//TODO
}
