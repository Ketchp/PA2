#pragma once

#include <string>

struct SStudent
{
    std::string m_name;
    int m_knowledge_level;
};
