#include "fraction.hpp"
#include <numeric>
